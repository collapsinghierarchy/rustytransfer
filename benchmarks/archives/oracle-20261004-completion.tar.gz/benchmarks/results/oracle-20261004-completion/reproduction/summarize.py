#!/usr/bin/env python3
"""Summarize version-1 Rustytransfer and Croc JSONL measurements."""

import argparse
import hashlib
import json
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path


SHA256 = re.compile(r"^[a-fA-F0-9]{64}$")
PROFILE_TIME_FIELDS = (
    "source_read_seconds",
    "allocation_copy_encrypt_seconds",
    "send_wait_seconds",
    "receive_wait_seconds",
    "decrypt_seconds",
    "destination_write_seconds",
)
PROFILE_SUBSTAGE_FIELDS = (
    "sender_allocation_copy_seconds",
    "sender_encrypt_seconds",
)
CONNECTION_SUMMARY_FIELDS = (
    "samples",
    "rtt_min_us",
    "rtt_max_us",
    "congestion_window_min_bytes",
    "congestion_window_max_bytes",
    "congestion_events_delta",
    "lost_packets_delta",
    "lost_bytes_delta",
    "udp_tx_bytes_delta",
    "udp_rx_bytes_delta",
    "data_blocked_frames_delta",
    "stream_data_blocked_frames_delta",
    "data_blocked_frames_rx_delta",
    "stream_data_blocked_frames_rx_delta",
    "send_wait_calls",
    "send_stalls_over_1ms",
    "send_stalls_over_10ms",
    "send_wait_max_us",
)
CONNECTION_NUMERIC_FIELDS = (
    "sample_interval_ms",
    "samples",
    "rtt_start_us",
    "rtt_end_us",
    "rtt_min_us",
    "rtt_max_us",
    "congestion_window_start_bytes",
    "congestion_window_end_bytes",
    "congestion_window_min_bytes",
    "congestion_window_max_bytes",
    "congestion_events_start",
    "congestion_events_end",
    "congestion_events_delta",
    "lost_packets_start",
    "lost_packets_end",
    "lost_packets_delta",
    "lost_bytes_start",
    "lost_bytes_end",
    "lost_bytes_delta",
    "udp_tx_datagrams_delta",
    "udp_tx_bytes_delta",
    "udp_rx_datagrams_delta",
    "udp_rx_bytes_delta",
    "data_blocked_frames_delta",
    "stream_data_blocked_frames_delta",
    "data_blocked_frames_rx_delta",
    "stream_data_blocked_frames_rx_delta",
    "send_wait_calls",
    "send_stalls_over_1ms",
    "send_stalls_over_10ms",
    "send_wait_max_us",
)
CONNECTION_NULLABLE_NUMERIC_FIELDS = {
    "rtt_start_us",
    "rtt_end_us",
    "rtt_min_us",
    "rtt_max_us",
    "congestion_window_start_bytes",
    "congestion_window_end_bytes",
    "congestion_window_min_bytes",
    "congestion_window_max_bytes",
    "congestion_events_start",
    "congestion_events_end",
    "congestion_events_delta",
}
GROUP_FIELDS = (
    "transport",
    "build_id",
    "sender_binary_sha256",
    "receiver_binary_sha256",
    "direction",
    "host_pair",
    "storage_class",
    "pairing_mode",
    "profile_mode",
    "completion_profile_enabled",
    "explicit_connection_close",
    "local_endpoint_working_directory",
    "stream_window_bytes",
    "experimental_protocol_version",
    "parallel_streams",
    "parallel_connections",
    "payload_key_count",
    "kem_sessions",
    "source_staging",
    "direct_route_verified_both",
    "legacy_input",
    "path",
    "size_bytes",
    "chunk_size",
    "pipeline_depth",
    "role",
    "transport_mode",
)


def median_absolute_deviation(values, center):
    return statistics.median(abs(value - center) for value in values)


def describe(values):
    center = statistics.median(values)
    return {
        "median": center,
        "minimum": min(values),
        "maximum": max(values),
        "mad": median_absolute_deviation(values, center),
    }


def group_key(record):
    key = []
    for field in GROUP_FIELDS:
        if field == "legacy_input":
            # Historical rows have no build provenance, so only combine them
            # when they came from the same input file. Keep that source visible.
            value = record.get("_legacy_input", "unknown") if record.get("build_id") is None else "unknown"
        else:
            value = record.get(field)
            if field == "profile_mode" and value is None:
                value = "standard"
            if field in ("completion_profile_enabled", "explicit_connection_close") and value is None:
                value = False
            if field == "source_staging" and value is None:
                value = "per-trial"
        key.append("unknown" if value is None else value)
    return tuple(key)


def completion_profile_rejection_reason(row):
    profile = row.get("completion_profile")
    if not isinstance(profile, dict):
        return "profile missing"
    required = {
        "setup_seconds", "application_wall_seconds", "transfer_lifetime_seconds",
        "protocol_confirmation_seconds", "finish_receiving_seconds", "endpoint_close_seconds",
    }
    if row.get("role") == "sender":
        required |= {"close_send_seconds", "wait_peer_close_seconds"}
    elif row.get("role") == "receiver":
        required |= {"receiver_commit_seconds", "finish_sending_seconds"}
    else:
        return "unknown endpoint role"
    if not required <= profile.keys():
        return "required lifecycle spans missing"
    for name, value in profile.items():
        if name.endswith("_seconds") and (
            not isinstance(value, (int, float)) or isinstance(value, bool)
            or not 0 <= value < float("inf")
        ):
            return f"invalid {name}"
    applied = profile.get("explicit_connection_close_applied")
    if not isinstance(applied, bool) or applied != row.get("explicit_connection_close", False):
        return "explicit-close application differs from requested mode"
    if applied and "explicit_connection_close_seconds" not in profile:
        return "explicit close duration missing"
    shutdown_names = {
        "protocol_confirmation_seconds", "receiver_commit_seconds", "close_send_seconds",
        "finish_receiving_seconds", "finish_sending_seconds", "wait_peer_close_seconds",
        "explicit_connection_close_seconds", "endpoint_close_seconds",
    }
    shutdown_sum = sum(profile.get(name, 0) for name in shutdown_names)
    if shutdown_sum > row.get("shutdown_seconds", -1) + 1e-5:
        return "completion spans exceed shutdown interval"
    if profile["setup_seconds"] + profile["transfer_lifetime_seconds"] > profile["application_wall_seconds"] + 1e-5:
        return "setup and transfer lifetimes exceed application lifetime"
    process_seconds = row.get("endpoint_process_seconds")
    if process_seconds is not None and profile["application_wall_seconds"] > process_seconds + 0.02:
        return "application lifetime exceeds endpoint process lifetime"
    return None


def payload_profile_rejection_reason(profile, bytes_transferred, payload_seconds):
    if not isinstance(profile, dict):
        return "payload profile is missing or invalid"
    if (
        not isinstance(bytes_transferred, int)
        or isinstance(bytes_transferred, bool)
        or bytes_transferred < 0
    ):
        return "payload profile endpoint byte count is missing or invalid"
    if (
        not isinstance(payload_seconds, (int, float))
        or isinstance(payload_seconds, bool)
        or not math.isfinite(payload_seconds)
        or payload_seconds < 0
    ):
        return "payload profile payload duration is missing or invalid"
    for field in PROFILE_TIME_FIELDS:
        value = profile.get(field)
        if (
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(value)
            or value < 0
        ):
            return "payload profile is missing or invalid"
    present_substages = [field in profile for field in PROFILE_SUBSTAGE_FIELDS]
    if any(present_substages) and not all(present_substages):
        return "payload profile sender substages are incomplete"
    if all(present_substages):
        substage_sum = 0.0
        for field in PROFILE_SUBSTAGE_FIELDS:
            value = profile[field]
            if (
                not isinstance(value, (int, float))
                or isinstance(value, bool)
                or not math.isfinite(value)
                or value < 0
            ):
                return "payload profile is missing or invalid"
            substage_sum += value
        if substage_sum > profile["allocation_copy_encrypt_seconds"] + 1e-6:
            return "payload profile sender substages exceed allocation/encrypt duration"
    for field in ("chunk_count", "payload_bytes"):
        value = profile.get(field)
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            return "payload profile is missing or invalid"
    if profile["payload_bytes"] != bytes_transferred:
        return "payload profile byte count does not match endpoint bytes"
    if profile["payload_bytes"] > 0 and profile["chunk_count"] == 0:
        return "payload profile chunk count is missing or invalid"
    try:
        stage_sum = math.fsum(profile[field] for field in PROFILE_TIME_FIELDS)
    except OverflowError:
        return "payload profile stage duration is invalid"
    if stage_sum > payload_seconds + 1e-6:
        return "payload profile stage durations exceed payload duration"
    return None


def connection_profile_rejection_reason(path_evidence):
    if path_evidence is None:
        return None
    if not isinstance(path_evidence, dict):
        return "path evidence is invalid"
    connection = path_evidence.get("connection_stats")
    if connection is None:
        return None
    if not isinstance(connection, dict):
        return "connection profile is invalid"
    for field in CONNECTION_NUMERIC_FIELDS:
        if field not in connection:
            continue
        value = connection[field]
        if value is None and field in CONNECTION_NULLABLE_NUMERIC_FIELDS:
            continue
        if (
            not isinstance(value, (int, float))
            or isinstance(value, bool)
            or not math.isfinite(value)
            or value < 0
        ):
            return "connection profile contains an invalid counter"
    return None


def load_records(input_paths):
    records = []
    for input_path in input_paths:
        source_id = "legacy-file-" + hashlib.sha256(
            str(input_path.resolve()).encode("utf-8")
        ).hexdigest()[:12]
        with input_path.open(encoding="utf-8") as source:
            for line in source:
                if line.strip():
                    record = json.loads(line)
                    if record.get("build_id") is None:
                        record["_legacy_input"] = source_id
                    records.append(record)
    return records


def rejection_reason(record):
    if record.get("success") is not True:
        return "transfer failed"
    if record.get("completion_profile_enabled"):
        completion_error = completion_profile_rejection_reason(record)
        if completion_error is not None:
            return f"invalid completion profile: {completion_error}"
    experiment_error = experimental_connection_rejection_reason(record)
    if experiment_error is not None:
        return experiment_error
    profile_mode = record.get("profile_mode", "standard")
    if profile_mode not in (None, "standard", "payload-profile"):
        return "profile mode is invalid"
    if profile_mode == "payload-profile":
        profile_error = payload_profile_rejection_reason(
            record.get("payload_profile"),
            record.get("bytes_transferred"),
            record.get("payload_seconds"),
        )
        if profile_error is not None:
            return profile_error
        connection_error = connection_profile_rejection_reason(record.get("path_evidence"))
        if connection_error is not None:
            return connection_error
    if record.get("source_staging", "per-trial") not in ("per-trial", "pre-staged"):
        return "source staging mode is invalid"
    if record.get("path") not in ("direct", "relay"):
        return "path is mixed, unknown, or auto"
    if record.get("transport") == "iroh" and record.get("path") == "direct":
        if record.get("direct_route_verified_both") is not True:
            return "direct route was not verified by both endpoints"
    source_hash = record.get("source_sha256")
    received_hash = record.get("received_sha256")
    if not isinstance(source_hash, str) or not SHA256.fullmatch(source_hash):
        return "source SHA-256 is missing or invalid"
    if not isinstance(received_hash, str) or not SHA256.fullmatch(received_hash):
        return "received SHA-256 is missing or invalid"
    if source_hash.lower() != received_hash.lower():
        return "source and received SHA-256 values do not match"

    wall = record.get("wall_seconds")
    if not isinstance(wall, (int, float)) or isinstance(wall, bool) or wall <= 0:
        return "wall duration is missing or invalid"
    try:
        wall = float(wall)
    except OverflowError:
        return "wall duration is missing or invalid"
    if not math.isfinite(wall):
        return "wall duration is missing or invalid"
    size_bytes = record.get("size_bytes")
    if not isinstance(size_bytes, int) or isinstance(size_bytes, bool) or size_bytes <= 0:
        return "size is missing or invalid"

    build_id = record.get("build_id")
    sender_binary_hash = record.get("sender_binary_sha256")
    receiver_binary_hash = record.get("receiver_binary_sha256")
    if build_id is not None:
        if not isinstance(build_id, str) or not build_id.strip():
            return "build ID is invalid"
        if not isinstance(sender_binary_hash, str) or not SHA256.fullmatch(sender_binary_hash):
            return "sender binary SHA-256 is missing or invalid"
        if not isinstance(receiver_binary_hash, str) or not SHA256.fullmatch(receiver_binary_hash):
            return "receiver binary SHA-256 is missing or invalid"
        for field in ("direction", "host_pair", "storage_class", "pairing_mode"):
            value = record.get(field)
            if not isinstance(value, str) or not value.strip():
                return f"{field} is missing or invalid"
    elif sender_binary_hash is not None or receiver_binary_hash is not None:
        if not isinstance(sender_binary_hash, str) or not SHA256.fullmatch(sender_binary_hash):
            return "sender binary SHA-256 is invalid"
        if not isinstance(receiver_binary_hash, str) or not SHA256.fullmatch(receiver_binary_hash):
            return "receiver binary SHA-256 is invalid"
    return None


def experimental_connection_rejection_reason(record):
    if record.get("experimental_protocol_version") != "shared-key-parallel/2":
        return None
    streams = record.get("parallel_streams")
    connections_count = record.get("parallel_connections")
    if (connections_count, streams) not in ((1, 1), (1, 4), (4, 4)):
        return "shared-key connection/stream geometry is invalid"
    if record.get("payload_key_count") != 1 or record.get("kem_sessions") != 1:
        return "shared-key crypto session count is invalid"
    connections = record.get("connection_evidence")
    if not isinstance(connections, list) or len(connections) != connections_count:
        return "per-connection route evidence is missing or incomplete"
    indices = []
    stable_ids = []
    ordered_items = []
    first_local = None
    first_remote = None
    for item in connections:
        if not isinstance(item, dict):
            return "per-connection route evidence is malformed"
        index = item.get("connection_index")
        stable_id = item.get("stable_id")
        indices.append(index)
        stable_ids.append(stable_id)
        ordered_items.append(item)
        if (
            not isinstance(index, int)
            or isinstance(index, bool)
            or not isinstance(stable_id, int)
            or isinstance(stable_id, bool)
            or stable_id < 0
        ):
            return "connection index or stable ID is invalid"
        local_id = item.get("local_endpoint_id")
        remote_id = item.get("remote_endpoint_id")
        if not isinstance(local_id, str) or not local_id or not isinstance(remote_id, str) or not remote_id:
            return "connection endpoint IDs are missing"
        if first_local is None:
            first_local, first_remote = local_id, remote_id
        elif local_id != first_local or remote_id != first_remote:
            return "connection endpoint IDs are inconsistent"
        if local_id == remote_id:
            return "local and remote endpoint IDs are identical"
        if item.get("path") != "direct" or item.get("path_start") != "direct" or item.get("path_end") != "direct":
            return "a data connection did not remain direct"
        evidence = item.get("path_evidence")
        if not (
            isinstance(evidence, dict)
            and evidence.get("classification") == "direct"
            and evidence.get("verified") is True
            and evidence.get("lagged") is False
            and evidence.get("missing_path_stats") is False
            and evidence.get("relay_selected") is False
            and evidence.get("relay_stream_tx") == 0
            and evidence.get("relay_stream_rx") == 0
            and (evidence.get("direct_stream_tx", 0) + evidence.get("direct_stream_rx", 0)) > 0
        ):
            return "strict direct STREAM evidence is missing for a data connection"
    if sorted(indices) != list(range(connections_count)):
        return "connection lane indices are missing or duplicated"
    if len(set(stable_ids)) != connections_count:
        return "stable connection IDs are duplicated"
    primary = sorted(ordered_items, key=lambda item: item["connection_index"])[0]
    if record.get("path_evidence") != primary.get("path_evidence"):
        return "primary connection evidence does not match endpoint path evidence"
    if record.get("path_start") != primary.get("path_start") or record.get("path_end") != primary.get("path_end"):
        return "primary connection path boundaries do not match endpoint path boundaries"
    if record.get("path") != "direct":
        return "aggregate experimental connection route is not direct"
    return None


def summarize_records(records):
    groups = defaultdict(list)
    rejected = defaultdict(int)
    for record in records:
        if record.get("warmup", False):
            continue
        key = group_key(record)
        reason = rejection_reason(record)
        if reason is not None:
            rejected[(key, reason)] += 1
            continue
        groups[key].append(record)

    rows = []
    for key, group_records in sorted(groups.items(), key=lambda item: json.dumps(item[0])):
        dimensions = dict(zip(GROUP_FIELDS, key))
        wall_durations = [float(record["wall_seconds"]) for record in group_records]
        size_mib = dimensions["size_bytes"] / (1024.0 * 1024.0)
        rates = [size_mib / duration for duration in wall_durations]
        phase_summaries = {}
        for field in ("handshake_seconds", "payload_seconds", "shutdown_seconds"):
            values = [record[field] for record in group_records if record.get(field) is not None]
            phase_summaries[field] = describe(values) if values else None
        resource_summaries = {}
        for field in (
            "sender_cpu_seconds",
            "receiver_cpu_seconds",
            "sender_max_rss_kib",
            "receiver_max_rss_kib",
        ):
            values = [record[field] for record in group_records if record.get(field) is not None]
            resource_summaries[field] = describe(values) if values else None
        profile_summary = None
        connection_summary = None
        if dimensions["profile_mode"] == "payload-profile":
            profile_summary = {
                field: describe([record["payload_profile"][field] for record in group_records])
                for field in (*PROFILE_TIME_FIELDS, "chunk_count", "payload_bytes")
            }
            for field in PROFILE_SUBSTAGE_FIELDS:
                profile_summary[field] = (
                    describe([record["payload_profile"][field] for record in group_records])
                    if all(field in record["payload_profile"] for record in group_records)
                    else None
                )
            connection_rows = [
                (record.get("path_evidence") or {}).get("connection_stats")
                for record in group_records
            ]
            if any(isinstance(value, dict) for value in connection_rows):
                connection_summary = {}
                for field in CONNECTION_SUMMARY_FIELDS:
                    values = [
                        value[field]
                        for value in connection_rows
                        if isinstance(value, dict)
                        and isinstance(value.get(field), (int, float))
                        and not isinstance(value.get(field), bool)
                    ]
                    connection_summary[field] = describe(values) if values else None
        rows.append(
            {
                **dimensions,
                "successful_runs": len(group_records),
                "effective_mib_per_second": describe(rates),
                "wall_seconds": describe(wall_durations),
                "handshake_seconds": phase_summaries["handshake_seconds"],
                "payload_seconds": phase_summaries["payload_seconds"],
                "shutdown_seconds": phase_summaries["shutdown_seconds"],
                "payload_profile": profile_summary,
                "connection_stats": connection_summary,
                "sender_cpu_seconds": resource_summaries["sender_cpu_seconds"],
                "receiver_cpu_seconds": resource_summaries["receiver_cpu_seconds"],
                "sender_max_rss_kib": resource_summaries["sender_max_rss_kib"],
                "receiver_max_rss_kib": resource_summaries["receiver_max_rss_kib"],
                "endpoint_process_cpu_and_rss_available": all(
                    record.get("sender_cpu_seconds") is not None
                    and record.get("receiver_cpu_seconds") is not None
                    and record.get("sender_max_rss_kib") is not None
                    and record.get("receiver_max_rss_kib") is not None
                    for record in group_records
                ),
            }
        )

    rejected_rows = []
    for (key, reason), count in sorted(
        rejected.items(), key=lambda item: json.dumps(item[0])
    ):
        rejected_rows.append(
            {
                **dict(zip(GROUP_FIELDS, key)),
                "count": count,
                "reason": reason,
            }
        )
    return {"schema_version": 1, "groups": rows, "rejected_rows": rejected_rows}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    result = summarize_records(load_records(args.inputs))

    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")


if __name__ == "__main__":
    main()
